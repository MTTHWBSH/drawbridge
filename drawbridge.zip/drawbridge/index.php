<?php get_header(); ?>

  	
  	  <div id="main">
  	
  	<!-- MAIN CONTENT -->
		
		<div class="content-left">
		
		<!-- ABOUT -->
			<section class="about">
				<h1 class="title">About Drawbridge</h1>
				<hr class="title">

				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque id ultrices purus. Aenean auctor 
				tellus sit amet turpis vulputate venenatis. In hac habitasse platea dictumst. Nulla facilisi. Fusce non 
				diam at odio gravida cursus id vel neque. Duis sit amet nisi mi. Fusce accumsan adipiscing placerat. 
				Vivamus lorem odio, vulputate in dignissim et, aliquam at tellus. Aliquam egestas felis vel enim iaculis 
				auctor feugiat tellus viverra. Duis lectus neque, tincidunt at tincidunt ac, volutpat nec massa. Aliquam 
				vitae justo diam, nec vestibulum lacus. Quisque vitae est mi, pellentesque ornare tellus. Cum sociis 
				natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>

				<p>Praesent mollis nibh ut magna elementum semper. Nunc tincidunt sem tortor. In fermentum libero et sem 
				fringilla nec sodales est molestie. Sed ut enim lorem, at vehicula nulla. Praesent pharetra, lorem quis 
				varius ornare, massa enim suscipit turpis, non blandit leo dui ut erat. Donec tincidunt, arcu eu pharetra 
				euismod, nibh est posuere velit, id bibendum orci tortor nec augue. Curabitur pulvinar lacinia magna eu f
				ringilla. Proin aliquam justo eget enim semper a ornare velit dictum. In ac tellus vitae lorem eleifend 
				porta eget vitae odio. Mauris eu nibh eget neque mollis ullamcorper. Nam sed enim ut metus iaculis 
				feugiat.</p>
		 
		 </section>
					
	  </div><!-- <div class="content-left"> -->

    <?php get_sidebar(); ?>
 	
  </div><!-- <div id="main"> -->  
 
<?php get_footer(); ?>